# csharp-aplikasi-perpustakaan
aplikasi perpustakan menggunakan mysql dan c#



# application requirement
1. visual studio 2012 atau lebih tinggi
2. crystal report for visual studio 2012 atau lebih tinggi
3. mysql/mariaDB database
4. mysql odbc
5. mysql connector net 6.5.4
6. .net framework 4

# cara install
1. buat database di mysql/mariaDB dengan nama db_perpus
2. kedua project memiliki file db.cs. ubah file tersebut pada variable koneksi_str dengan server, database, username, password anda dan tambahkan convert zero datetime=true
4. jalankan aplikasi.

# fitur aplikasi
1. 3 level menu administrator(admin, katalog, pelayanan)
2. laporan peminjaman dan pengembalian
3. pencarian, sorting dan paging data
4. pencarian buku dan input buku tamu
5. desain yang simple
